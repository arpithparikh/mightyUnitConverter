//1. Open index.html in browser to run the app.
//2. Actual Logic in js Folder.
//3. color logic in css file
